﻿# Define el archivo de hosts
$hostsfile = "$env:windir\System32\drivers\etc\hosts"

# Define el patrón para buscar el nombre y la dirección IP
$pattern = "^(\S+)\s+\S+\s+([\d\.]+)"

# Lee las líneas y busca el patrón
multipass list | ForEach-Object {
    if ($_ -match $pattern) {
        $hostname = $matches[1]
        $ip = $matches[2]

        # Verifica si la entrada ya existe en el archivo hosts
        $existing_entry = Get-Content -Path $hostsfile | Where-Object { $_ -match "^$ip\s+$hostname\s*$" }

        # Si la entrada no existe, agrégala al archivo hosts
        if (!$existing_entry) {
            Add-Content -Path $hostsfile -Value "$ip $hostname"
            Write-Output "Se agregó la entrada $ip $hostname al archivo hosts."
        } else {
            Write-Output "La entrada $ip $hostname ya existe en el archivo hosts."
        }
    }
}